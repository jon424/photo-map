declare class AzureStorageService {
    private containerClient;
    constructor();
    uploadPhoto(file: Express.Multer.File, filename: string): Promise<string>;
    deletePhoto(filename: string): Promise<void>;
    getPhotoUrl(filename: string): Promise<string>;
}
export default AzureStorageService;
//# sourceMappingURL=storage-client.d.ts.map