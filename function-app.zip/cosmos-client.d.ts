export interface PhotoData {
    id: string;
    filename: string;
    latitude: number;
    longitude: number;
    timestamp: string;
    description?: string;
    blobUrl?: string;
}
declare class CosmosDBService {
    private client;
    private database;
    private container;
    constructor();
    createPhoto(photoData: PhotoData): Promise<PhotoData>;
    getPhoto(id: string): Promise<PhotoData | null>;
    getAllPhotos(): Promise<PhotoData[]>;
    updatePhoto(id: string, updates: Partial<PhotoData>): Promise<PhotoData>;
    deletePhoto(id: string): Promise<void>;
}
export default CosmosDBService;
//# sourceMappingURL=cosmos-client.d.ts.map