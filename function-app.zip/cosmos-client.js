"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const cosmos_1 = require("@azure/cosmos");
class CosmosDBService {
    constructor() {
        const endpoint = process.env.COSMOS_ENDPOINT;
        const key = process.env.COSMOS_KEY;
        const databaseName = process.env.COSMOS_DATABASE || 'photodb';
        const containerName = process.env.COSMOS_CONTAINER || 'photos';
        if (!endpoint || !key) {
            throw new Error('Cosmos DB configuration missing. Please set COSMOS_ENDPOINT and COSMOS_KEY environment variables.');
        }
        this.client = new cosmos_1.CosmosClient({ endpoint, key });
        this.database = this.client.database(databaseName);
        this.container = this.database.container(containerName);
    }
    async createPhoto(photoData) {
        try {
            const { resource } = await this.container.items.create(photoData);
            return resource;
        }
        catch (error) {
            console.error('Error creating photo in Cosmos DB:', error);
            throw new Error('Failed to save photo to database');
        }
    }
    async getPhoto(id) {
        try {
            const { resource } = await this.container.item(id, id).read();
            return resource;
        }
        catch (error) {
            if (error.code === 404) {
                return null;
            }
            console.error('Error getting photo from Cosmos DB:', error);
            throw new Error('Failed to retrieve photo from database');
        }
    }
    async getAllPhotos() {
        try {
            const { resources } = await this.container.items
                .query({
                query: 'SELECT * FROM c ORDER BY c.timestamp DESC'
            })
                .fetchAll();
            return resources;
        }
        catch (error) {
            console.error('Error getting all photos from Cosmos DB:', error);
            throw new Error('Failed to retrieve photos from database');
        }
    }
    async updatePhoto(id, updates) {
        try {
            const { resource } = await this.container.item(id, id).replace({
                id,
                ...updates
            });
            return resource;
        }
        catch (error) {
            console.error('Error updating photo in Cosmos DB:', error);
            throw new Error('Failed to update photo in database');
        }
    }
    async deletePhoto(id) {
        try {
            await this.container.item(id, id).delete();
        }
        catch (error) {
            console.error('Error deleting photo from Cosmos DB:', error);
            throw new Error('Failed to delete photo from database');
        }
    }
}
exports.default = CosmosDBService;
//# sourceMappingURL=cosmos-client.js.map